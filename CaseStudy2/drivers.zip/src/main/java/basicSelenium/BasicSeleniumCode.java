package basicSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BasicSeleniumCode {

	WebDriver driver;

	/**
	 * 
	 * @param browser 
	 * valid browser are chrome, firefox, ie, edge
	 * @param url
	 * pass the url with http:// or https://
	 */
	public void setupBrowser(String browser, String url) {
		String currDir = System.getProperty("user.dir");

		if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", currDir+"\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", currDir+"\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else {
			System.out.println("Driver object is not provided or valid, hence not invoking the browser");
			System.exit(0);
		}

		driver.manage().window().maximize();
		
		if(url!="")
			driver.get(url);//opening the url
		else {
			System.out.println("url is not provided and hence quiting the test run");
			quitBrowser();			
		}
	}

	public void quitBrowser() {
		if(driver!=null)
			driver.quit();
	}
	
	public void closeWindow() {
		driver.close();
	}
	
	
	public void locatorTest() {
		
		//id
//		driver.findElement(By.id("email")).sendKeys("ramesh@gmail.com");
		
		//name
//		driver.findElement(By.name("email")).sendKeys("from name");
		
		//classname
//		driver.findElement(By.className("login_form_input_box")).sendKeys("from classname");
		
		//tagname
//		driver.findElement(By.tagName("input")).sendKeys("from tagname");
		
		//link text
//		driver.findElement(By.linkText("Forgotten account?")).click();
		
		//partial link text
//		driver.findElement(By.partialLinkText("?")).click();
		
		//css selector
//		driver.findElement(By.cssSelector("#email")).sendKeys("from css selector");
		driver.findElement(By.cssSelector("inputtext.#email")).sendKeys("css");
		
		//xpath
//		driver.findElement(By.xpath("//input[@data-testid='royal_email']")).sendKeys("from xpath");
//		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("9886098860");
//		driver.findElement(By.xpath("//input[contains(@id, 'email')]")).sendKeys("from contains");
//		driver.findElement(By.xpath("//input[starts-with(@data-testid, 'royal_email')]")).sendKeys("from starts with");
//		driver.findElement(By.xpath("//a[text()='Forgotten account?']")).click();
//		driver.findElement(By.xpath("//input[@id='email']//input")).sendKeys("abcd");
//		driver.findElement(By.xpath("//a[contains(text(), 'Forgotten')]")).click();
//		driver.findElement(By.xpath("//input['name' and 'email']")).sendKeys("from and");

	}


	
//	public static void main(String[] args) {
//		BasicSeleniumCode sel = new BasicSeleniumCode();
//		sel.setupBrowser("chrome", "https://www.facebook.com");
//		sel.locatorTest();
//		sel.quitBrowser();
//	}

}
