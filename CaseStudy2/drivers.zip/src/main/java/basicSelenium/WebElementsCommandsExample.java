package basicSelenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebElementsCommandsExample {

	WebDriver driver;

	public void setupBrowser(String browser, String url) {
		String currDir = System.getProperty("user.dir");

		if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", currDir+"\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", currDir+"\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else {
			System.out.println("Driver object is not provided or valid, hence not invoking the browser");
			System.exit(0);
		}

		driver.manage().window().maximize();
		if(url!="")
			driver.get(url);//opening the url
		else {
			System.out.println("url is not provided and hence quiting the test run");
			quitBrowser();			
		}
	}

	public void quitBrowser() {
		if(driver!=null)
			driver.quit();
	}
	public void closeBrowser() {
		if(driver!=null)
			driver.close();
	}
	
	public void webElementsValidation() {
//		System.out.println(driver.findElement(By.id("email")).getSize());
//		System.out.println(driver.findElement(By.id("email")).getAttribute("class"));
//		System.out.println(driver.findElement(By.xpath("//label[@for='email']")).getCssValue("font-size"));
//		System.out.println(driver.findElement(By.xpath("//label[@for='email']")).getCssValue("color"));
//		System.out.println(driver.findElement(By.xpath("//label[@for='email']")).getTagName());
//		System.out.println(driver.findElement(By.id("email")).getTagName());
//		System.out.println(driver.findElement(By.partialLinkText("For")).getText());
		WebElement femaleRadioBtn = driver.findElement(By.id("u_0_6"));
//		System.out.println(femaleRadioBtn.isDisplayed());
//		System.out.println(femaleRadioBtn.isEnabled());
		System.out.println(femaleRadioBtn.isSelected());
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		femaleRadioBtn.click();
		
		System.out.println(femaleRadioBtn.isSelected());
		
		
	}
	
	
	
	public static void main(String[] args) {
		WebElementsCommandsExample sel = new WebElementsCommandsExample();
		sel.setupBrowser("chrome", "https://www.fb.com");
		sel.webElementsValidation();
//		sel.closeBrowser();
		sel.quitBrowser();
	}

}
