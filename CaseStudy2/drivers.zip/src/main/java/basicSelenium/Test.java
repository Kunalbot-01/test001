package basicSelenium;



import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

public class Test {

	static WebDriver driver;


	public void openBrowser(String browserType, String url){

//		String currentDir = System.getProperty("user.dir");

//		if (browserType.equalsIgnoreCase("firefox")){
//			System.setProperty("webdriver.gecko.driver", currentDir+"\\drivers\\geckodriver.exe");
//			driver = new FirefoxDriver();
//		}
//		else if (browserType.equalsIgnoreCase("chrome")){
//			System.setProperty("webdriver.chrome.driver", currentDir+"\\drivers\\chromedriver.exe");
//			driver = new ChromeDriver();
//		}
//		else if (browserType.equalsIgnoreCase("ie")){
//			System.setProperty("webdriver.ie.driver", currentDir+"\\drivers\\IEDriverserver.exe");
//			driver = new InternetExplorerDriver();
//		}
//		else if (browserType.equalsIgnoreCase("htmlunitdriver")){
////			driver = new HtmlUnitDriver();
//		}

		if (browserType.equalsIgnoreCase("firefox")){
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else if (browserType.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (browserType.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverserver.exe");
			driver = new InternetExplorerDriver();
		}
		else if (browserType.equalsIgnoreCase("htmlunitdriver")){
//			driver = new HtmlUnitDriver();
		}

		if(url.isEmpty()){
			url = "about:blank";
		}

		driver.manage().window().maximize();
		driver.get(url);
	}

	public void closeBrowser(){
		if (driver != null){
//			driver.close();
			driver.quit();
		}
	}

	public void robotExample() throws AWTException, InterruptedException {
		driver.findElement(By.xpath("html/body/header/section/section[1]/figure")).click();
		Robot robot = new Robot();
		String fileName = "G:\\Edureka\\autoit\\download.jpg";
		StringSelection stringSelection = new StringSelection(fileName);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
		
	}
	

	public static void main(String[] args) throws AWTException, InterruptedException {
		Test driver = new Test();
		driver.openBrowser("chrome", "https://tinypng.com/");
		driver.robotExample();
//		driver.closeBrowser();


	}


}
