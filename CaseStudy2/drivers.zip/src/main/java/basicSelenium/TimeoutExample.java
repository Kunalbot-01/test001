package basicSelenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TimeoutExample {

	WebDriver driver;

	public void setupBrowser(String browser, String url) {
		String currDir = System.getProperty("user.dir");

		if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", currDir+"\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", currDir+"\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else {
			System.out.println("Driver object is not provided or valid, hence not invoking the browser");
			System.exit(0);
		}

		driver.manage().window().maximize();
		//		driver.manage().timeouts().implicitlyWait(1, TimeUnit.NANOSECONDS);
		//		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(1000, TimeUnit.SECONDS);

		if(url!="")
			driver.get(url);//opening the url
		else {
			System.out.println("url is not provided and hence quiting the test run");
			quitBrowser();			
		}
	}

	public void quitBrowser() {
		if(driver!=null)
			driver.quit();
	}
	public void closeBrowser() {
		if(driver!=null)
			driver.close();
	}

	public void scriptTest() {
		((JavascriptExecutor) driver).executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 500);");
	}

	public static void main(String[] args) {
		TimeoutExample sel = new TimeoutExample();
		sel.setupBrowser("chrome", "https://www.fb.com");
		sel.scriptTest();
		sel.quitBrowser();
	}

}
