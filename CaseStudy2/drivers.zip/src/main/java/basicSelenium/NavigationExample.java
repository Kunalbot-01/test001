package basicSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NavigationExample {

	WebDriver driver;

	/**
	 * 
	 * @param browser 
	 * valid browser are chrome, firefox, ie, edge
	 * @param url
	 * pass the url with http:// or https://
	 */
	public void setupBrowser(String browser, String url) {
		String currDir = System.getProperty("user.dir");

		if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", currDir+"\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", currDir+"\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else {
			System.out.println("Driver object is not provided or valid, hence not invoking the browser");
			System.exit(0);
		}

		driver.manage().window().maximize();
		
		if(url!="")
			driver.get(url);//opening the url
		else {
			System.out.println("url is not provided and hence quiting the test run");
			quitBrowser();			
		}
	}

	public void quitBrowser() {
		if(driver!=null)
			driver.quit();
	}
	public void closeBrowser() {
		if(driver!=null)
			driver.close();
	}
	
	public void navigation() {
//		driver.navigate().to("https://www.google.com");
//		driver.navigate().back();
//		driver.navigate().forward();
		driver.navigate().refresh();
	}
	
	
	
	public static void main(String[] args) {
		NavigationExample sel = new NavigationExample();
		sel.setupBrowser("chrome", "https://www.fb.com");
		sel.navigation();
//		sel.closeBrowser();
//		sel.quitBrowser();
	}

}
